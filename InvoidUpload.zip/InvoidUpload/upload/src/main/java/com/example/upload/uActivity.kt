package com.example.upload

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class uActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_uactivity)


        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
}