package com.example.upload;

import android.app.Activity;

public class MainActivity extends Activity {
}
